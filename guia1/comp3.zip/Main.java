import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner notas = new Scanner(System.in);
    int num =0;
    int numeros;
    int conta2 = 0;
    int conta1=0;

    System.out.println("ingrese la cantidad de numeros que desea");
    numeros=notas.nextInt();
    while (num<numeros) {
      double numerito;
      num=num+1;
      System.out.println("ingrese los numeros");
      numerito = notas.nextDouble();
      if (numerito%2==0) {
        conta1 = conta1 + 1;
      } else {
        conta2 = conta2 + 1;
      }
    }
    System.out.println("son par:" + conta1);
    System.out.println("son impar" + conta2);
  }
}
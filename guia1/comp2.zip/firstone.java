import java.util.*;

class firstone {
  public static void main(String[] args) {
    Scanner notas = new Scanner(System.in);
    int n1, n2;
    System.out.println("bienvenido, este es un programa para conocer si 2 numeros son divisibles entre si");
    System.out.println("por favor digite el primer numero");
    n1 = notas.nextInt();
    System.out.println("por favor digite el segundo numero");
    n2 = notas.nextInt();
    if (n1 % n2 == 0) {
      System.out.println("los numeros son divisibles");
    } else {
      System.out.println("no son divisibles");
    }
  }
}
import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner notas = new Scanner(System.in);
    int notass = 0;
    int conta1 = 0;
    int conta2 = 0;

    System.out.println("ingrese 10 notas obtenidas acontinuacion");
    while (notass < 10) {
      double nota1;
      System.out.println("ingrese las notas");
      nota1 = notas.nextDouble();
      if (nota1 >= 7) {
        conta1 = conta1 + 1;
      } else {
        conta2 = conta2 + 1;
      }
      notass = notass + 1;
    }
    System.out.println("notas mayores a 7 son:" + conta1);
    System.out.println("notas menores a 7 son:" + conta2);
  }
}

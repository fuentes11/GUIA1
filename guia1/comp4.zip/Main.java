import java.util.*;

class Main {

  public static void main(String[] args) {
    Scanner equisye = new Scanner(System.in);
    double c1 = 0, c2 = 0, c3 = 0, c4 = 0;
    int cantidad;
    System.out.println("cuantos puntos desea procesar?");
    cantidad = equisye.nextInt();
    for (int i= 1; i<= cantidad; i++){
    double x, y;
    System.out.println("ingrese x");
    x = equisye.nextDouble();
    System.out.println("ingrese y");
    y = equisye.nextDouble();
    if (x > 0 && y > 0) {
      c1++;
    }
    if (x < 0 && y > 0) {
      c2++;
    }
    if (x < 0 && y < 0) {
      c3++;
    }
    if (x > 0 && y < 0) {
      c4++;
    }
    }
    System.out.println("puntos para el primer cuadrante" + c1);
    System.out.println("puntos para el segundo cuadrante" + c2);
    System.out.println("puntos para el tercero cuadrante" + c3);
    System.out.println("puntos para el cuarto cuadrante" + c4);
  }
}